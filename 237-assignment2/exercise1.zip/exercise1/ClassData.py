'''
@author Hannah Raju

'''

classmates = {}
classmates["Hannah"] = {"George", "Frank", "Adam"}
classmates["Ema"] = {"Dolly", "Bob", "Adam"}
classmates["Adam"] = {"Ema","Bob", "Hannah"}
classmates["Bob"] = {"Adam", "Ema", "Dolly"}
classmates["Dolly"] = {"Bob", "Ema"}
classmates["Frank"] = {"Hannah"}
classmates["George"] = {"Hannah"}